<?php get_header(); ?>

			<div id="content">

				<div id="inner-content" class="wrap clearfix">

					<div id="main" class="eightcol first clearfix" role="main">

						<article id="post-not-found" class="hentry clearfix">

							<header class="article-header">

								<h1><?php _e("404 Not Found", "ballball"); ?></h1>

							</header> <!-- end article header -->

							<section class="entry-content">
							</section> <!-- end article section -->

							<section class="search">
							</section> <!-- end search section -->

							<footer class="article-footer">
							</footer> <!-- end article footer -->

						</article> <!-- end article -->

					</div> <!-- end #main -->

				</div> <!-- end #inner-content -->

			</div> <!-- end #content -->

<?php get_footer(); ?>
